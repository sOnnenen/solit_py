import numpy as np
import matplotlib.pyplot as plt
import Environment
import Agent

env = Environment.Board()
agent = Agent.Agent()

finish_reward = 100000
scale = 300
q_low = -100
q_high = -10
jump_reward = 1
dead_penalty = -1000

env.set_params(scale, jump_reward, finish_reward, dead_penalty)
observation_space = env.observation_space()
action_space = env.action_space()
q_table = np.random.uniform(low=q_low, high=q_high, size=(observation_space[0], observation_space[1], action_space))
episodes = 100000

for discount in range(4, 5, 1):
    for learning_rate in range(4, 5, 1):
        agent.set_params(learning_rate / 10, discount / 10, 33, 32)
        new_q_table, plot = agent.run_agent(episodes, 5000, False, env, q_table)
        q_file = "Q_Table_" + str(discount) + "_" + str(learning_rate)
        plot_file = "Plot_" + str(discount) + "_" + str(learning_rate)
        np.save(q_file, new_q_table)
        plot.savefig(plot_file, format="pdf")
        plt.close(plot)
        q_file += ".npy"
        game_file = "Game" + str(discount) + "_" + str(learning_rate) + ".png"
        agent.play_table_save(q_file, env, game_file)
