import numpy as np
import matplotlib.pyplot as plt


class Agent:

    def __init__(self):
        self.learning_rate = 0.5
        self.discount = 0.5

        # Epsilon depending on number of remaining pins
        self.epsilon = (0, 0, 0, .026, .041, .117, .242, .367, .488, .602, .702, .782, .841, .883, .911, .911, .943,
                        .952, .959, .965, .969, .973, .977, .979, .98, .981, .98, .977, .96, .857, .5, 0)

        # Remaining pins must be smaller than EX_PIN in order to maybe choose next action randomly
        self.exploration_pin = 33
        self.starting_pins = 32  # Number of Pins to start with [1 - 32]

    def set_params(self, learning_rate, discount, exploration_pin, starting_pins):
        self.learning_rate = learning_rate
        self.discount = discount
        self.exploration_pin = exploration_pin
        self.starting_pins = starting_pins

    # get action with highest possible q table value, given current state and possible actions
    @staticmethod
    def get_action(q_table, c_state, acts):
        action_list = []
        for act in acts:
            value = q_table[c_state][act]
            action_list.append([act, value])
        max_act = action_list[0][0]
        max_val = action_list[0][1]
        for k in action_list:
            if k[1] > max_val:
                max_val = k[1]
                max_act = k[0]
        return max_act

    # get epsilon value for given number of remaining pins and current episode
    def get_eps(self, num_pins, episodes, current_episode):
        epsilon = self.epsilon[32 - num_pins]
        slope = 1 / episodes
        epsilon *= 1 - current_episode * slope
        return epsilon

    def play_table_save(self, table, environment, filename):
        q_table = np.load(table)
        if self.starting_pins < 32:
            state, actions = environment.load_board(self.starting_pins)
        else:
            state, actions = environment.reset()

        done = False
        while not done:
            environment.play()
            action = self.get_action(q_table, state, actions)
            state, reward, actions, done = environment.action(action)
        environment.play()
        environment.save_game(filename)

    def run_agent(self, episodes, show_every, visualize, environment, table):
        ep_rewards = []
        aggr_ep_rewards = {'ep': [], 'avg': [], 'min': [], 'max': []}
        dead_end_count = np.zeros(self.starting_pins)
        goal_count = []
        pins_reward = []
        reward_pins = []
        q_table = table
        for episode in range(1, episodes + 1):
            episode_reward = 0
            if not episode % show_every:
                play = visualize
            else:
                play = False

            if self.starting_pins < 32:
                state, actions = environment.load_board(self.starting_pins)
            else:
                state, actions = environment.reset()

            done = False
            while not done:
                if play:
                    environment.play()
                if np.random.random() < self.get_eps(state[1], episodes, episode) and state[1] < self.exploration_pin:
                    action = actions[np.random.randint(0, len(actions))]
                else:
                    action = self.get_action(q_table, state, actions)

                new_state, reward, actions, done = environment.action(action)
                episode_reward += reward

                if not done:
                    max_future_q = np.max(q_table[new_state][actions])
                    current_q = q_table[state][action]
                    new_q = current_q + self.learning_rate * (reward + self.discount * max_future_q - current_q)
                    q_table[state][action] = new_q
                elif not new_state[0] and not new_state[1]:
                    q_table[state][action] = reward
                    if play:
                        environment.play()
                    goal_count.append(episode)
                else:
                    q_table[state][action] = reward
                    if play:
                        environment.play()
                    pins = list(state)[1]
                    dead_end_count[pins - 1] += 1

                state = new_state

            # episode reward for later plot
            if state[1] < 16:
                pins_reward.append(state[1] + 1)
                reward_pins.append(episode_reward)
            ep_rewards.append(episode_reward)

            if not episode % show_every:
                average_reward = sum(ep_rewards[-show_every:]) / len(ep_rewards[-show_every:])
                aggr_ep_rewards['ep'].append(episode)
                aggr_ep_rewards['avg'].append(average_reward)
                aggr_ep_rewards['min'].append(min(ep_rewards[-show_every:]))
                aggr_ep_rewards['max'].append(max(ep_rewards[-show_every:]))

                print(f"Episode: {episode} avg: {average_reward} min: "
                      f"{min(ep_rewards[-show_every:])} max: {max(ep_rewards[-show_every:])}")

        dead_end_per = np.zeros(self.starting_pins)
        i = 0
        for count in dead_end_count:
            dead_end_per[i] = count * 100 / episodes
            i += 1

        fig = plt.figure(figsize=(10, 14))
        plt.subplot(3, 1, 1)
        plt.plot(aggr_ep_rewards['ep'], aggr_ep_rewards['avg'], 'o-', linewidth=2, color='cyan')
        plt.ylabel("Average Reward")
        plt.xlabel("Episode")
        plt.grid()

        plt.subplot(3, 1, 2)
        plt.bar(range(1, len(dead_end_count) + 1), dead_end_per, 0.9, color='red')
        plt.ylabel("Games finished\nwith [x] pins left in [%]")
        plt.xlabel("Number of pins")
        plt.grid()

        plt.subplot(3, 1, 3)
        plt.scatter(pins_reward, reward_pins, marker='1', linewidth=1.2, color='magenta')
        plt.ylabel("Scored reward")
        plt.xlabel("Number of pins")
        plt.grid()

        print("Goals in Episodes", goal_count)

        return q_table, fig
