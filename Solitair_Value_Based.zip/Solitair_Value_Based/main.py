import numpy as np
import matplotlib.pyplot as plt
import Environment

env = Environment.Board()

LEARNING_RATE = 0.4
DISCOUNT = 0.95
PRE_EPISODES = 10000    # Max episodes for board configurations with number of pins smaller than actual
EPISODES = 50000    # Max episodes for actual board configuration
SHOW_EVERY = 10000  # Visualizes the game every SHOW_EVERY
LIVE_SIGNAL_EVERY = 1000    # Prints message of current episode every LIVE_SIGNAL_EVERY
START_EPISODES = 5  # Number of episodes for board configurations with number of pins smaller than 10
INCREASE = 3    # Number of episodes increases for every additional pin
EPS_PRE = 0.5   # Epsilon for small board configurations (no decaying)

# Values for epsilon and decaying
epsilon = 0.8
START_EPSILON_DECAYING = 1
END_EPSILON_DECAYING = EPISODES // 2
epsilon_decay_value = epsilon / (END_EPSILON_DECAYING - START_EPSILON_DECAYING)

action_space = env.action_space()   # number of theoretically possible actions
observation_space = env.observation_space()  # size of state

q_table = np.random.uniform(low=-2, high=0, size=(observation_space[0], observation_space[1], action_space))

ep_rewards = []
aggr_ep_rewards = {'ep': [], 'avg': [], 'min': [], 'max': []}


# get action with highest possible q table value given current state and possible actions
def get_action(table, c_state, acts):
    action_list = []
    for act in acts:
        value = table[c_state][act]
        action_list.append([act, value])
    max_act = action_list[0][0]
    max_val = action_list[0][1]
    for i in action_list:
        if i[1] > max_val:
            max_val = i[1]
            max_act = i[0]
    return max_act


# Routine for smaller board configurations
for pins in range(2, 25):

    if pins < 10:
        times = START_EPISODES * (INCREASE ** (pins - 2))   # Number of episodes for pins smaller than 10
    else:
        times = PRE_EPISODES

    while times:
        if times % LIVE_SIGNAL_EVERY == 0:
            print("I'm alive in time", times, "and pins", pins)

        done = False
        state, actions = env.load_board(pins)
        while not done:
            if np.random.random() > EPS_PRE:
                action = get_action(q_table, state, actions)    # Getting action based on max outcome
            else:
                action = actions[np.random.randint(0, len(actions))]    # Getting action randomly

            new_state, reward, actions, done = env.action(action)

            if not done:    # Calculating new q value
                max_future_q = np.max(q_table[new_state][actions])
                current_q = q_table[state][action]
                new_q = (1 - LEARNING_RATE) * current_q + LEARNING_RATE * (reward + DISCOUNT * max_future_q)
                q_table[state][action] = new_q
            elif not new_state[0] and not new_state[1]:
                q_table[state][action] = reward  # Reward for reaching goal
                print("\t\t\t\tI reached goal!!!", pins, times)
            else:
                q_table[state][action] = reward  # Penalty for reaching dead end

            state = new_state
        times -= 1


# Routine for standard board configuration (similar to previous routine, with visualization)
for episode in range(EPISODES):
    episode_reward = 0
    if episode % LIVE_SIGNAL_EVERY == 0:
        print("I'm alive in episode", episode)
    if episode % SHOW_EVERY == 0:
        play = True
    else:
        play = False

    state, actions = env.reset()
    done = False
    while not done:
        if play:
            env.play()
        if np.random.random() > epsilon:
            action = get_action(q_table, state, actions)
        else:
            action = actions[np.random.randint(0, len(actions))]

        new_state, reward, actions, done = env.action(action)
        episode_reward += reward

        if not done:
            max_future_q = np.max(q_table[new_state][actions])
            current_q = q_table[state][action]
            new_q = (1 - LEARNING_RATE) * current_q + LEARNING_RATE * (reward + DISCOUNT * max_future_q)
            q_table[state][action] = new_q
        elif not new_state[0] and not new_state[1]:
            q_table[state][action] = reward
            if play:
                env.play()
            print("\t\t\t\tI reached goal!!!", episode)
        else:
            q_table[state][action] = reward
            if play:
                env.play()

        state = new_state

    if END_EPSILON_DECAYING >= episode >= START_EPSILON_DECAYING:
        epsilon -= epsilon_decay_value

    # episode reward for later plot
    ep_rewards.append(episode_reward)

    if not episode % SHOW_EVERY:
        average_reward = sum(ep_rewards[-SHOW_EVERY:]) / len(ep_rewards[-SHOW_EVERY:])
        aggr_ep_rewards['ep'].append(episode)
        aggr_ep_rewards['avg'].append(average_reward)
        aggr_ep_rewards['min'].append(min(ep_rewards[-SHOW_EVERY:]))
        aggr_ep_rewards['max'].append(max(ep_rewards[-SHOW_EVERY:]))

        print(f"Episode: {episode} avg: {average_reward} min: "
              f"{min(ep_rewards[-SHOW_EVERY:])} max: {max(ep_rewards[-SHOW_EVERY:])}")

plt.plot(aggr_ep_rewards['ep'], aggr_ep_rewards['avg'], label="avg")
plt.plot(aggr_ep_rewards['ep'], aggr_ep_rewards['min'], label="min")
plt.plot(aggr_ep_rewards['ep'], aggr_ep_rewards['max'], label="max")
plt.legend(loc=4)
plt.show()
