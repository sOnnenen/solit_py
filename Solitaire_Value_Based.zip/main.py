import numpy as np
import matplotlib.pyplot as plt
import Environment

VIS_GAME = False    # Visualize game?
SHOW_EVERY = 500  # Visualizes the game every SHOW_EVERY

LEARNING_RATE = 0.65
DISCOUNT = 0.35

EPISODES = 20000    # Max episodes for actual board configuration
LIVE_SIGNAL_EVERY = 1000    # Prints message of current episode every LIVE_SIGNAL_EVERY

PRE_EPISODES = 20000    # Max episodes for board configurations with number of pins smaller than actual
EPS_PRE = 0.5   # Epsilon for small board configurations (no decaying)
PRE_PIN = 17    # Number of pins for training on smaller board configurations

EX_PIN = 33     # Remaining pins must be smaller than EX_PIN in order to maybe choose next action randomly

# Values for epsilon and decaying
epsilon = 1
START_EPSILON_DECAYING = 1
END_EPSILON_DECAYING = EPISODES // 1.5
epsilon_decay_value = epsilon / (END_EPSILON_DECAYING - START_EPSILON_DECAYING)

env = Environment.Board()
action_space = env.action_space()   # number of theoretically possible actions
observation_space = env.observation_space()  # size of state
ep_rewards = []
aggr_ep_rewards = {'ep': [], 'avg': [], 'min': [], 'max': []}
goal_count = []
dead_end_count = np.zeros(32)

while True:
    load = input("Load Q-Table? [y:yes, n:no] ")
    if load == "y" or load == "yes":
        filename = input("Filename: ")
        q_table = np.load(filename)
        break
    elif load == "n" or load == "no":
        q_table = np.random.uniform(low=-100, high=-10, size=(observation_space[0], observation_space[1], action_space))
        break
    else:
        print("Answer not valid. Try again.")


# get action with highest possible q table value, given current state and possible actions
def get_action(table, c_state, acts):
    action_list = []
    for act in acts:
        value = table[c_state][act]
        action_list.append([act, value])
    max_act = action_list[0][0]
    max_val = action_list[0][1]
    for k in action_list:
        if k[1] > max_val:
            max_val = k[1]
            max_act = k[0]
    return max_act


# Routine for random board configuration with PRE_PIN pins
for pre_episode in range(PRE_EPISODES):

    if pre_episode % LIVE_SIGNAL_EVERY == 0:
        print("I'm alive in pre_episode", pre_episode)

    done = False
    state, actions = env.load_board(PRE_PIN)
    while not done:
        if np.random.random() > EPS_PRE:
            action = get_action(q_table, state, actions)    # Getting action based on max outcome
        else:
            action = actions[np.random.randint(0, len(actions))]    # Getting action randomly

        new_state, reward, actions, done = env.action(action)

        if not done:    # Calculating new q value
            max_future_q = np.max(q_table[new_state][actions])
            current_q = q_table[state][action]
            new_q = (1 - LEARNING_RATE) * current_q + LEARNING_RATE * (reward + DISCOUNT * max_future_q)
            q_table[state][action] = new_q
        elif not new_state[0] and not new_state[1]:
            q_table[state][action] = reward  # Reward for reaching goal
            print("\t\t\t\tI reached goal!!!", pre_episode)
        else:
            q_table[state][action] = reward  # Penalty for reaching dead end

        state = new_state


# Routine for standard board configuration (similar to previous routine, with visualization)
for episode in range(EPISODES):
    episode_reward = 0
    if episode % SHOW_EVERY == 0:
        play = VIS_GAME
    else:
        play = False

    state, actions = env.reset()
    done = False
    while not done:
        if play:
            env.play()
        if np.random.random() < epsilon and state[1] < EX_PIN:
            action = actions[np.random.randint(0, len(actions))]
        else:
            action = get_action(q_table, state, actions)

        new_state, reward, actions, done = env.action(action)
        episode_reward += reward

        if not done:
            max_future_q = np.max(q_table[new_state][actions])
            current_q = q_table[state][action]
            new_q = current_q + LEARNING_RATE * (reward + DISCOUNT * max_future_q - current_q)
            q_table[state][action] = new_q
        elif not new_state[0] and not new_state[1]:
            q_table[state][action] = reward
            if play:
                env.play()
            print("\t\t\t\tI reached goal!!!", episode)
            goal_count.append(episode)
        else:
            q_table[state][action] = reward
            if play:
                env.play()
            pins = list(state)[1]
            dead_end_count[pins - 1] += 1

        state = new_state

    if END_EPSILON_DECAYING >= episode >= START_EPSILON_DECAYING:
        epsilon -= epsilon_decay_value

    # episode reward for later plot
    ep_rewards.append(episode_reward)

    if not episode % SHOW_EVERY:
        average_reward = sum(ep_rewards[-SHOW_EVERY:]) / len(ep_rewards[-SHOW_EVERY:])
        aggr_ep_rewards['ep'].append(episode)
        aggr_ep_rewards['avg'].append(average_reward)
        aggr_ep_rewards['min'].append(min(ep_rewards[-SHOW_EVERY:]))
        aggr_ep_rewards['max'].append(max(ep_rewards[-SHOW_EVERY:]))

        print(f"Episode: {episode} avg: {average_reward} min: "
              f"{min(ep_rewards[-SHOW_EVERY:])} max: {max(ep_rewards[-SHOW_EVERY:])}")

print(goal_count)

fig = plt.figure(figsize=(10, 7))
plt.subplot(2, 1, 1)
plt.plot(aggr_ep_rewards['ep'], aggr_ep_rewards['avg'], '.-', label="avg")
plt.plot(aggr_ep_rewards['ep'], aggr_ep_rewards['min'], '.-', label="min")
plt.plot(aggr_ep_rewards['ep'], aggr_ep_rewards['max'], '.-', label="max")
plt.ylabel("Reward")
plt.xlabel("Episode")
plt.legend(loc=4)

dead_end_per = np.zeros(32)
i = 0
for dead in dead_end_count:
    dead_end_per[i] = dead * 100 / EPISODES
    i += 1

plt.subplot(2, 1, 2)
plt.plot(range(1, len(dead_end_count) + 1), dead_end_per, '.-')
plt.ylabel("Number of games finished\nwith [x] pins left in [%]")
plt.xlabel("Number of pins")
plt.show()

while True:
    save = input("Save Q-Table? [y:yes, n:no] ")
    if save == "y" or save == "yes":
        filename = input("Filename: ")
        np.save(filename, q_table)
        break
    elif save == "n" or save == "no":
        break
    else:
        print("Answer not valid. Try again.")
